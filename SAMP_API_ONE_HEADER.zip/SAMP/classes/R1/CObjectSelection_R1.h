/*
	This is a SAMP (0.3.7-R1) API project file.
	Developer: LUCHARE <luchare.dev@gmail.com>
	
	See more here https://github.com/LUCHARE/SAMP-API
	
	Copyright (c) 2018 BlastHack Team <BlastHack.Net>. All rights reserved.
*/

#pragma once

#ifdef SAMP_R1_COMPILE

#include "common_R1.h"

SAMP_BEGIN

class SAMP_API CObjectSelection {
public:
	BOOL m_bIsActive;
	ID	  m_nHoveredObject;
	
	CObjectSelection();

	ID DefineObject();
	void DrawLabels();
	void Enable(BOOL bEnable);
	void Draw();
	void SendNotification();
	BOOL MsgProc(int uMsg, int wParam, int lParam);
};

extern CObjectSelection *&pObjectSelection;

SAMP_END

#endif